import os
import time
from pathlib import Path

from arduino.app_utils import App, Bridge
from config import DIRECTIONS, load_settings
from robot_client import MiniAutoRobot, ProgramStopped

PYTHON_DIR = Path(__file__).resolve().parent
DATA_DIR = Path(os.environ.get("ROBOCAR_DATA_DIR", PYTHON_DIR.parent / "data"))

cfg = load_settings(Path(os.environ.get("ROBOCAR_TUNING", PYTHON_DIR / "tuning.json")))


class QuickRobot(MiniAutoRobot):
    """drive() without the starter's sensor read before and after every pulse:
    each read also polls the I2C sensors and costs up to ~0.5 s when one is
    slow, which made every step take ~2 s. The pilot checks the run state once
    per step, and BOOT stops the motors in the MCU immediately anyway."""

    def drive(self, command: str, speed: int = 150, ms: int = 500) -> None:
        Bridge.call("drive", command, int(speed), int(ms))
        time.sleep(ms / 1000.0 + 0.03)


robot = QuickRobot() if cfg.quick_drive else MiniAutoRobot()


def motion_check() -> None:
    # Start with raised wheels; calibrate this short pulse on each chassis.
    sweep = DIRECTIONS if cfg.test_direction == "all" else tuple(cfg.test_direction.split(","))
    for i, direction in enumerate(sweep, 1):
        command = cfg.direction_map.get(direction, direction)
        print(f"test move {i}/{len(sweep)}: {direction} (firmware {command}) "
              f"speed={cfg.test_speed} ms={cfg.test_ms}")
        robot.drive(command, speed=cfg.test_speed, ms=max(20, cfg.test_ms))
        if i < len(sweep):
            time.sleep(2.0)  # time to see where it went before the next move


ROUTINES = {"motion_check": motion_check}
camera = detector = None
try:
    from camera import MjpegCamera
    from pilot import Pilot
    from vision import ColorDetector, build_detector
except ImportError as exc:
    # The motion check must still work while OpenCV is missing.
    print(f"[ERROR] {exc}. Run the app once while the UNO Q has Internet so "
          "python/requirements.txt installs; only mode 'motion_check' works until then.")
else:
    camera = MjpegCamera(cfg.camera_url)
    try:
        detector = build_detector(cfg, PYTHON_DIR)
    except Exception as exc:
        print(f"[ERROR] detector {cfg.detector!r} failed to start: {exc}")
        if cfg.detector != "color":
            # A missing or broken model must not cost the run: color still works.
            print("[WARN] falling back to the color detector")
            detector = ColorDetector(cfg)
    if detector is not None:
        pilot = Pilot(robot, camera, detector, cfg, DATA_DIR, button_stop=ProgramStopped)
        ROUTINES.update(play=pilot.play, observe=pilot.observe)

try:
    robot.stop()
    print(f"health : {robot.health()}")
    print(f"sensors : {robot.read_sensors()}")
    if cfg.mode not in ROUTINES:
        raise SystemExit(f"[ERROR] mode {cfg.mode!r} is unavailable; see the error above")
    if camera is not None:
        camera.start()
    detector_name = detector.name if detector else "none"
    print(f"mode : {cfg.mode}, detector : {detector_name}, camera : {cfg.camera_url}")
    print("Short-press the camera BOOT button to start; press again to stop.")
    routine = ROUTINES[cfg.mode]

    def user_loop() -> None:
        robot.run_program(routine)
        # Idle polling otherwise floods the Bridge; stopping the app mid-message
        # then leaves the MCU unresponsive until it is reset.
        time.sleep(0.05)

    App.run(user_loop=user_loop)
finally:
    robot.stop()
    if camera is not None:
        camera.close()
    if detector is not None:
        detector.close()
