"""Minimal client for an Edge Impulse .eim model.

A .eim file is a Linux executable that serves JSON over a Unix socket. Talking
to it directly avoids the edge-impulse-linux package and its audio
dependencies, which have to be installed before the UNO Q loses Internet.
"""

from __future__ import annotations

import json
import os
import shutil
import socket
import stat
import subprocess
import tempfile
import time
from pathlib import Path


class EimRunner:
    def __init__(self, model_path: Path, timeout_s: float = 5.0) -> None:
        self.model_path = Path(model_path)
        self.timeout_s = timeout_s
        self._proc: subprocess.Popen | None = None
        self._sock: socket.socket | None = None
        self._tmp: str | None = None
        self._next_id = 1

    def start(self) -> dict:
        self._tmp = tempfile.mkdtemp(prefix="eim-")
        executable = self._executable()
        sock_path = os.path.join(self._tmp, "runner.sock")
        self._proc = subprocess.Popen([str(executable), sock_path],
                                      stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        deadline = time.monotonic() + 15
        while not os.path.exists(sock_path):
            if self._proc.poll() is not None:
                raise RuntimeError(f"{self.model_path.name} exited with code {self._proc.returncode}; "
                                   "is it built for Linux aarch64 (Arduino UNO Q target)?")
            if time.monotonic() > deadline:
                raise TimeoutError(f"{self.model_path.name} did not open its socket")
            time.sleep(0.05)
        self._sock = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
        self._sock.settimeout(self.timeout_s)
        self._sock.connect(sock_path)
        return self._send({"hello": 1})

    def _executable(self) -> Path:
        """Unzipping (as `make flash` does) drops the executable bit. Restore
        it, or run a private copy if the app folder cannot be modified."""
        exec_bits = stat.S_IXUSR | stat.S_IXGRP | stat.S_IXOTH
        mode = self.model_path.stat().st_mode
        if mode & stat.S_IXUSR:
            return self.model_path
        try:
            os.chmod(self.model_path, mode | exec_bits)
            return self.model_path
        except OSError:
            copy = Path(self._tmp) / self.model_path.name
            shutil.copyfile(self.model_path, copy)
            os.chmod(copy, 0o700)
            return copy

    def classify(self, features: list[int]) -> dict:
        return self._send({"classify": features})

    def _send(self, msg: dict) -> dict:
        if self._sock is None:
            raise RuntimeError("model runner not started")
        msg["id"] = self._next_id
        self._next_id += 1
        self._sock.sendall(json.dumps(msg).encode())
        data = bytearray()
        while not data.endswith(b"\0"):
            chunk = self._sock.recv(65536)
            if not chunk:
                raise ConnectionError("model runner closed the socket")
            data += chunk
        resp = json.loads(data[:-1])
        if not resp.get("success"):
            raise RuntimeError(f"model error: {resp.get('error')}")
        return resp

    def close(self) -> None:
        if self._sock:
            self._sock.close()
            self._sock = None
        if self._proc and self._proc.poll() is None:
            self._proc.terminate()
            try:
                self._proc.wait(timeout=2)
            except subprocess.TimeoutExpired:
                self._proc.kill()
        if self._tmp:
            shutil.rmtree(self._tmp, ignore_errors=True)
