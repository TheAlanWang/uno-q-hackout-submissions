"""MJPEG reader that always holds the newest frame.

A background thread drains the stream continuously, so nothing queues up
behind a slow decision loop and every frame carries its arrival time.
"""

from __future__ import annotations

import threading
import time
from dataclasses import dataclass
from urllib.request import urlopen

import cv2
import numpy as np

SOI = b"\xff\xd8"
EOI = b"\xff\xd9"


class StaleVideo(Exception):
    """No new frame arrived within the allowed time."""


@dataclass(frozen=True)
class Frame:
    jpeg: bytes
    t: float    # time.monotonic() when the last byte arrived
    seq: int

    def decode(self) -> np.ndarray:
        image = cv2.imdecode(np.frombuffer(self.jpeg, np.uint8), cv2.IMREAD_COLOR)
        if image is None:
            raise ValueError(f"frame {self.seq} is not a valid JPEG")
        return image


class MjpegCamera:
    def __init__(self, url: str, timeout_s: float = 2.0, max_buffer: int = 1 << 20) -> None:
        self.url = url
        self.timeout_s = timeout_s
        self.max_buffer = max_buffer
        self.error: str | None = "not started"
        self._cond = threading.Condition()
        self._latest: Frame | None = None
        self._seq = 0
        self._stop = threading.Event()
        self._thread: threading.Thread | None = None
        self._arrivals: list[float] = []

    def start(self) -> None:
        if self._thread and self._thread.is_alive():
            return
        self._stop.clear()
        self._thread = threading.Thread(target=self._run, name="mjpeg", daemon=True)
        self._thread.start()

    def close(self) -> None:
        self._stop.set()
        if self._thread:
            self._thread.join(timeout=self.timeout_s + 1)

    def latest(self) -> Frame | None:
        with self._cond:
            return self._latest

    def fps(self) -> float:
        with self._cond:
            times = list(self._arrivals)
        if len(times) < 2 or time.monotonic() - times[-1] > 1.0:
            return 0.0
        return (len(times) - 1) / (times[-1] - times[0])

    def wait_frame(self, newer_than: float, timeout_s: float, min_seq: int = 0) -> Frame:
        """Return the newest frame that arrived after `newer_than` and has a
        sequence number of at least `min_seq`. Raises StaleVideo when no new
        frame at all arrives for `timeout_s`, however many frames it waits for."""
        deadline = time.monotonic() + timeout_s
        seen = None
        with self._cond:
            while (self._latest is None or self._latest.t <= newer_than
                   or self._latest.seq < min_seq):
                if self._latest is not None and self._latest.seq != seen:
                    if seen is not None:
                        deadline = time.monotonic() + timeout_s
                    seen = self._latest.seq
                remaining = deadline - time.monotonic()
                if remaining <= 0:
                    detail = self.error or "stream stalled"
                    raise StaleVideo(f"no new frame for {timeout_s:.1f}s ({detail})")
                self._cond.wait(remaining)
            return self._latest

    def _run(self) -> None:
        while not self._stop.is_set():
            try:
                self._read_stream()
            except Exception as exc:  # reconnect on any network failure
                self.error = f"{type(exc).__name__}: {exc}"
            self._stop.wait(1.0)

    def _read_stream(self) -> None:
        with urlopen(self.url, timeout=self.timeout_s) as resp:
            self.error = None
            read = getattr(resp, "read1", resp.read)
            buf = bytearray()
            while not self._stop.is_set():
                chunk = read(16384)
                if not chunk:
                    raise ConnectionError("stream ended")
                buf += chunk
                self._extract_frames(buf)
                if len(buf) > self.max_buffer:
                    del buf[:-1]

    def _extract_frames(self, buf: bytearray) -> None:
        while True:
            start = buf.find(SOI)
            if start < 0:
                del buf[:-1]  # keep a trailing 0xFF that may begin the next SOI
                return
            end = buf.find(EOI, start + 2)
            if end < 0:
                del buf[:start]
                return
            jpeg = bytes(buf[start:end + 2])
            del buf[:end + 2]
            self._publish(jpeg)

    def _publish(self, jpeg: bytes) -> None:
        now = time.monotonic()
        with self._cond:
            self._seq += 1
            self._latest = Frame(jpeg, now, self._seq)
            self._arrivals = (self._arrivals + [now])[-30:]
            self._cond.notify_all()
