"""Ball and goal detectors. Both return the same Detections so the decision
logic does not care which one is running."""

from __future__ import annotations

import math
from collections import deque
from pathlib import Path

import cv2
import numpy as np

from config import Settings
from observation import Ball, Detections, Goal


CLOSE_KERNEL = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (5, 5))
OPEN_KERNEL = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (3, 3))


def hsv_mask(hsv: np.ndarray, ranges: list) -> np.ndarray:
    mask = np.zeros(hsv.shape[:2], np.uint8)
    for lo, hi in ranges:
        mask |= cv2.inRange(hsv, np.array(lo, np.uint8), np.array(hi, np.uint8))
    # Fill holes first (a soccer ball's dark patches split its white area),
    # then drop specks with a small kernel that a distant ball survives.
    mask = cv2.morphologyEx(mask, cv2.MORPH_CLOSE, CLOSE_KERNEL)
    return cv2.morphologyEx(mask, cv2.MORPH_OPEN, OPEN_KERNEL)


def find_horizon(bgr: np.ndarray, cfg: Settings) -> float:
    """Row where the floor ends, found in each frame so a bumped camera mount
    does not matter: scanning up from the bottom, the dark carpet gives way to
    the bright room. Falls back to horizon_y_frac when there is no clear edge
    (e.g. the frame is all floor)."""
    h = bgr.shape[0]
    fallback = cfg.horizon_y_frac * h
    if not cfg.auto_horizon:
        return fallback
    value = cv2.cvtColor(bgr, cv2.COLOR_BGR2HSV)[..., 2].astype(np.float32)
    rows = np.convolve(value.mean(axis=1), np.ones(9) / 9, mode="same")
    floor = float(np.median(rows[int(0.8 * h):int(0.95 * h)]))
    room = float(np.percentile(rows[int(0.05 * h):int(0.6 * h)], 80))
    if room - floor < cfg.horizon_min_contrast:
        return fallback
    threshold = floor + cfg.horizon_threshold * (room - floor)
    y = int(0.95 * h)
    while y > 0 and rows[y] < threshold:
        y -= 1
    return float(min(max(y + 1, 0.1 * h), 0.75 * h))


class HorizonFilter:
    """Median of the last few per-frame horizon estimates: the camera tilt
    does not change between frames, while an arm or a person walking through
    the view briefly throws a single estimate off."""

    def __init__(self, cfg: Settings, frames: int = 15) -> None:
        self.cfg = cfg
        self.recent: deque[float] = deque(maxlen=frames)

    def __call__(self, bgr: np.ndarray) -> float:
        self.recent.append(find_horizon(bgr, self.cfg))
        return float(np.median(self.recent))


def floor_line(cfg: Settings, horizon: float, height: int) -> int:
    """Image row above which nothing can be the ball."""
    return int(horizon - cfg.ball_above_horizon_frac * height)


def fits_floor(cfg: Settings, ball: Ball, horizon: float) -> bool:
    """On a flat floor a ball's image radius grows with its distance below the
    horizon, so blobs that are far too big (or too small) for their row are
    background clutter, not the ball."""
    drop = ball.cy - horizon
    if drop <= 0:
        return False
    return cfg.ball_floor_ratio_min <= ball.r / drop <= cfg.ball_floor_ratio_max


def hough_balls(bgr: np.ndarray, cfg: Settings) -> list[Ball]:
    """Bright round outlines, brightest first."""
    gray = cv2.GaussianBlur(cv2.cvtColor(bgr, cv2.COLOR_BGR2GRAY), (5, 5), 1.2)
    found = cv2.HoughCircles(gray, cv2.HOUGH_GRADIENT, dp=1, minDist=10, param1=120, param2=14,
                             minRadius=3, maxRadius=40)
    if found is None:
        return []
    value = cv2.cvtColor(bgr, cv2.COLOR_BGR2HSV)[..., 2]
    balls = []
    for x, y, r in found[0]:
        disc = np.zeros(gray.shape, np.uint8)
        cv2.circle(disc, (int(x), int(y)), max(1, int(r * 0.8)), 255, -1)
        bright = float((value[disc > 0] >= cfg.ball_hsv[0][0][2]).mean()) if cfg.ball_hsv else 0.0
        if bright >= 0.5:
            balls.append(Ball(float(x), float(y), float(r), min(1.0, bright)))
    return sorted(balls, key=lambda b: -b.score)


def _contours(mask: np.ndarray) -> list:
    return cv2.findContours(mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)[-2]


def find_ball(mask: np.ndarray, min_area: float, min_roundness: float) -> Ball | None:
    balls = find_balls(mask, min_area, min_roundness)
    return balls[0] if balls else None


def find_balls(mask: np.ndarray, min_area: float, min_roundness: float) -> list[Ball]:
    """Round blobs in the mask, most ball-like first."""
    h, w = mask.shape[:2]
    ranked: list[tuple[float, Ball]] = []
    for contour in _contours(mask):
        area = cv2.contourArea(contour)
        if area < min_area:
            continue
        (cx, cy), r = cv2.minEnclosingCircle(contour)
        # Shape from the convex hull, so the dark patches of a soccer ball
        # biting into the white outline do not make it look less round.
        hull = cv2.convexHull(contour)
        hull_area = cv2.contourArea(hull)
        perimeter = cv2.arcLength(hull, True)
        circularity = 4 * math.pi * hull_area / (perimeter * perimeter) if perimeter else 0.0
        fill = hull_area / (math.pi * r * r) if r else 0.0
        roundness = min(1.0, 0.5 * circularity + 0.5 * fill)
        # A ball cut by the frame edge looks less round; do not reject it for that.
        x, y, bw, bh = cv2.boundingRect(contour)
        clipped = x <= 1 or y <= 1 or x + bw >= w - 1 or y + bh >= h - 1
        if roundness < (min_roundness * 0.7 if clipped else min_roundness):
            continue
        ranked.append((roundness * math.sqrt(area), Ball(cx, cy, r, roundness)))
    return [ball for _, ball in sorted(ranked, key=lambda item: -item[0])]


def white_enough(hsv: np.ndarray, ball: Ball, cfg: Settings) -> bool:
    """The ball's bright pixels are near-white (saturation 5-21 on Q03); a
    pale yellow cone up close is not (~80). Only applies to a white ball range."""
    if not cfg.ball_hsv or max(hi[1] for _, hi in cfg.ball_hsv) > 150:
        return True
    disc = np.zeros(hsv.shape[:2], np.uint8)
    cv2.circle(disc, (int(ball.cx), int(ball.cy)), max(2, int(ball.r * 0.8)), 255, -1)
    pixels = hsv[disc > 0]
    bright = pixels[pixels[:, 2] >= 170]
    return len(bright) == 0 or float(np.median(bright[:, 1])) <= cfg.ball_max_saturation


def without_cones(balls: list[Ball], cones: list[tuple[int, int, int, int]]) -> list[Ball]:
    return [b for b in balls
            if not any(x - 2 <= b.cx <= x + w + 2 and y - 2 <= b.cy <= y + h + 2 for x, y, w, h in cones)]


def find_goal(mask: np.ndarray, min_area: float) -> Goal | None:
    """The largest goal-colored blob joined with blobs at a similar height,
    so two separate posts form one goal but a stray patch elsewhere does not."""
    blobs = [(cv2.contourArea(c), cv2.boundingRect(c)) for c in _contours(mask)]
    blobs = [(a, box) for a, box in blobs if a >= min_area]
    if not blobs:
        return None
    _, (_, my, _, mh) = max(blobs)

    def same_band(box) -> bool:
        _, y, _, h = box
        overlap = min(my + mh, y + h) - max(my, y)
        return overlap >= 0.5 * min(mh, h)

    boxes = [box for _, box in blobs if same_band(box)]
    x0 = min(x for x, _, _, _ in boxes)
    y0 = min(y for _, y, _, _ in boxes)
    x1 = max(x + bw for x, _, bw, _ in boxes)
    y1 = max(y + bh for _, y, _, bh in boxes)
    return Goal(x0, y0, x1, y1, 1.0, parts=len(boxes))


def find_cone_boxes(mask: np.ndarray, cfg: Settings, horizon: float) -> list[tuple[int, int, int, int]]:
    """Cone-shaped blobs standing on the floor: at least about as tall as wide
    and clearly narrower at the top than at the bottom (a ball is not)."""
    cones = []
    for contour in _contours(mask):
        if cv2.contourArea(contour) < cfg.goal_min_area_px:
            continue
        x, y, w, h = cv2.boundingRect(contour)
        if h < cfg.cone_min_height_ratio * w or y + h <= horizon + 2 or h < 6:
            continue
        blob = np.zeros((h, w), np.uint8)
        cv2.drawContours(blob, [contour - (x, y)], -1, 255, -1)
        top = int(np.count_nonzero(blob[h // 4]))
        bottom = int(np.count_nonzero(blob[(3 * h) // 4]))
        if bottom == 0 or top > cfg.cone_max_taper * bottom:
            continue
        cones.append((x, y, w, h))
    return cones


def find_cones(cones: list[tuple[int, int, int, int]]) -> Goal | None:
    """The pair of cones whose bases line up best is the goal. One cone alone
    gives a partial goal (parts=1), so the brain only uses which side it is on."""
    if not cones:
        return None
    best = None
    for i, a in enumerate(cones):
        for b in cones[i + 1:]:
            gap = abs((a[1] + a[3]) - (b[1] + b[3]))
            tall = max(a[3], b[3])
            if gap > max(6, 0.35 * tall) or max(a[3], b[3]) > 2.2 * min(a[3], b[3]):
                continue
            if best is None or gap < best[0]:
                best = (gap, a, b)
    if best:
        _, a, b = best
        boxes, parts = (a, b), 2
    else:
        boxes, parts = (max(cones, key=lambda c: c[2] * c[3]),), 1
    return Goal(min(x for x, _, _, _ in boxes), min(y for _, y, _, _ in boxes),
                max(x + w for x, _, w, _ in boxes), max(y + h for _, y, _, h in boxes),
                1.0, parts=parts)


class ColorDetector:
    name = "color"

    def __init__(self, cfg: Settings) -> None:
        self.cfg = cfg
        self.horizon = HorizonFilter(cfg)

    def masks(self, bgr: np.ndarray, horizon: float | None = None) -> tuple[np.ndarray, np.ndarray | None]:
        if horizon is None:
            horizon = find_horizon(bgr, self.cfg)
        hsv = cv2.cvtColor(cv2.GaussianBlur(bgr, (5, 5), 0), cv2.COLOR_BGR2HSV)
        ball = hsv_mask(hsv, self.cfg.ball_hsv)
        # The ball is on the floor: white walls, ceiling, windows and glare
        # above the horizon are never it. (Cones can rise above it, so the
        # goal mask is kept.)
        top = floor_line(self.cfg, horizon, ball.shape[0])
        if top > 0:
            ball[:top] = 0
        goal = hsv_mask(hsv, self.cfg.goal_hsv) if self.cfg.goal_hsv else None
        return ball, goal

    def candidates(self, bgr: np.ndarray, ball_mask: np.ndarray, horizon: float) -> list[Ball]:
        """Ball candidates that fit the floor, best first: round white blobs,
        else bright circles (a far ball can merge with a bright background
        in the color mask, but its round outline still shows)."""
        cfg = self.cfg
        hsv = cv2.cvtColor(bgr, cv2.COLOR_BGR2HSV)
        blobs = find_balls(ball_mask, cfg.ball_min_area_px, cfg.ball_min_roundness)
        on_floor = [b for b in blobs if fits_floor(cfg, b, horizon) and white_enough(hsv, b, cfg)]
        if on_floor or not cfg.ball_hough:
            return on_floor
        return [b for b in hough_balls(bgr, cfg) if fits_floor(cfg, b, horizon) and white_enough(hsv, b, cfg)]

    def detect(self, bgr: np.ndarray) -> Detections:
        horizon = self.horizon(bgr)
        ball_mask, goal_mask = self.masks(bgr, horizon)
        goal, cones = self.goal(goal_mask, horizon)
        balls = without_cones(self.candidates(bgr, ball_mask, horizon), cones)
        return Detections(balls[0] if balls else None, goal, tuple(balls), horizon)

    def goal(self, goal_mask: np.ndarray | None, horizon: float):
        """(goal, cone boxes). Pale cones also pass the white ball colour, so
        their boxes are used to drop ball candidates sitting on a cone."""
        if goal_mask is None:
            return None, []
        if self.cfg.goal_shape == "cones":
            cones = find_cone_boxes(goal_mask, self.cfg, horizon)
            return find_cones(cones), cones
        return find_goal(goal_mask, self.cfg.goal_min_area_px), []

    def close(self) -> None:
        pass


class _OfficialRunner:
    """edge-impulse-linux's ImageImpulseRunner behind the EimRunner interface."""

    def __init__(self, path: Path) -> None:
        from edge_impulse_linux.image import ImageImpulseRunner

        self._runner = ImageImpulseRunner(str(path))

    def start(self) -> dict:
        return self._runner.init()

    def classify(self, features: list[int]) -> dict:
        return self._runner.classify(features)

    def close(self) -> None:
        self._runner.stop()


def open_model(path: Path):
    """Start the .eim with the official runner when installed, else the
    built-in socket client. Returns (runner, model_info)."""
    try:
        runner, kind = _OfficialRunner(path), "edge-impulse-linux"
    except ImportError:
        from eim_runner import EimRunner

        runner, kind = EimRunner(path), "built-in client"
    info = runner.start()
    print(f"[INFO] model {path.name} via {kind}")
    return runner, info


class EimDetector:
    """Edge Impulse FOMO model (.eim) exported for the UNO Q."""

    name = "eim"

    def __init__(self, cfg: Settings, model_dir: Path, runner=None, info: dict | None = None) -> None:
        self.cfg = cfg
        if runner is None:
            path = model_dir / cfg.eim_model if cfg.eim_model else next(iter(sorted(model_dir.glob("*.eim"))), None)
            if path is None or not path.exists():
                raise FileNotFoundError(f"no .eim model found in {model_dir}")
            runner, info = open_model(path)
        self.runner = runner
        self.horizon = HorizonFilter(cfg)
        params = info["model_parameters"]
        self.in_w = int(params["image_input_width"])
        self.in_h = int(params["image_input_height"])
        self.gray = int(params.get("image_channel_count", 3)) == 1
        print(f"[INFO] model input {self.in_w}x{self.in_h}, labels {params.get('labels')}")

    def features(self, bgr: np.ndarray) -> list[int]:
        # Squash to the model input, matching the "Squash" resize used in training.
        small = cv2.resize(bgr, (self.in_w, self.in_h), interpolation=cv2.INTER_AREA)
        if self.gray:
            g = cv2.cvtColor(small, cv2.COLOR_BGR2GRAY).astype(np.uint32)
            packed = (g << 16) | (g << 8) | g
        else:
            rgb = small.astype(np.uint32)
            packed = (rgb[..., 2] << 16) | (rgb[..., 1] << 8) | rgb[..., 0]
        return packed.ravel().tolist()

    def boxes(self, bgr: np.ndarray) -> list[dict]:
        """Model detections above eim_min_score, in frame pixels."""
        h, w = bgr.shape[:2]
        sx, sy = w / self.in_w, h / self.in_h
        result = self.runner.classify(self.features(bgr))["result"]
        return [{"label": b["label"], "value": b["value"], "x": b["x"] * sx, "y": b["y"] * sy,
                 "w": b["width"] * sx, "h": b["height"] * sy}
                for b in result.get("bounding_boxes", []) if b["value"] >= self.cfg.eim_min_score]

    def detect(self, bgr: np.ndarray) -> Detections:
        boxes = self.boxes(bgr)
        horizon = self.horizon(bgr)
        balls = [b for b in boxes if b["label"] == self.cfg.eim_ball_label
                 and b["y"] + b["h"] / 2 > horizon + self.cfg.model_hit_below_horizon_px]
        ball = None
        if balls:
            b = max(balls, key=lambda b: b["value"])
            ball = Ball(b["x"] + b["w"] / 2, b["y"] + b["h"] / 2, max(b["w"], b["h"]) / 2, b["value"])

        goals = [b for b in boxes if b["label"] == self.cfg.eim_goal_label]
        goal = None
        if goals:
            # FOMO marks cells, not objects: count distinct posts as separated clusters.
            centers = sorted(b["x"] + b["w"] / 2 for b in goals)
            parts = 1 + sum(1 for a, b in zip(centers, centers[1:]) if b - a > 0.15 * bgr.shape[1])
            goal = Goal(min(b["x"] for b in goals), min(b["y"] for b in goals),
                        max(b["x"] + b["w"] for b in goals), max(b["y"] + b["h"] for b in goals),
                        max(b["value"] for b in goals), parts=parts)
        return Detections(ball, goal, (ball,) if ball else (), horizon)

    def close(self) -> None:
        self.runner.close()


class HybridDetector:
    """The model decides *whether* a blob is the soccer ball (white shoes and
    paper are rejected); color gives its exact center and radius, which FOMO's
    fixed-size cells cannot. Goal posts come from color."""

    name = "hybrid"

    def __init__(self, cfg: Settings, color: ColorDetector, model: EimDetector) -> None:
        self.cfg = cfg
        self.color = color
        self.model = model

    def detect(self, bgr: np.ndarray) -> Detections:
        horizon = self.color.horizon(bgr)
        ball_mask, goal_mask = self.color.masks(bgr, horizon)
        goal, cones = self.color.goal(goal_mask, horizon)
        candidates = without_cones(self.color.candidates(bgr, ball_mask, horizon), cones)
        # The ball is on the floor: model hits on cups, shirts, windows or
        # glare at or above the horizon are ignored, like the color mask does.
        hits = sorted((b for b in self.model.boxes(bgr)
                       if b["label"] == self.cfg.eim_ball_label
                       and b["y"] + b["h"] / 2 > horizon + self.cfg.model_hit_below_horizon_px),
                      key=lambda b: -b["value"])
        ball = None
        for hit in hits:  # a hit confirmed by a white round blob beats any unconfirmed one
            hx, hy = hit["x"] + hit["w"] / 2, hit["y"] + hit["h"] / 2
            near = [c for c in candidates
                    if math.hypot(c.cx - hx, c.cy - hy) <= self.cfg.eim_match_px + c.r]
            if near:
                c = min(near, key=lambda c: math.hypot(c.cx - hx, c.cy - hy))
                ball = Ball(c.cx, c.cy, c.r, hit["value"])
                break
        if ball is None:
            # A far ball is only a few pixels at the model's input size, below
            # what FOMO can see, so small round blobs that fit the floor pass on
            # their own; they outrank an unconfirmed model hit, which in testing
            # was usually glare.
            small = [c for c in candidates if c.r < self.cfg.eim_trust_color_below_px]
            if small:
                ball = small[0]
        if ball is None and hits:
            # Model is sure but the color mask missed it (shadow): coarse position.
            hit = hits[0]
            ball = Ball(hit["x"] + hit["w"] / 2, hit["y"] + hit["h"] / 2,
                        max(hit["w"], hit["h"]) / 2, hit["value"] * 0.8)
        others = tuple(c for c in candidates if ball is None or (c.cx, c.cy) != (ball.cx, ball.cy))
        return Detections(ball, goal, ((ball,) if ball else ()) + others, horizon)

    def close(self) -> None:
        self.model.close()


def build_detector(cfg: Settings, model_dir: Path):
    if cfg.detector == "eim":
        return EimDetector(cfg, model_dir)
    if cfg.detector == "color":
        return ColorDetector(cfg)
    if cfg.detector == "hybrid":
        return HybridDetector(cfg, ColorDetector(cfg), EimDetector(cfg, model_dir))
    raise ValueError(f"unknown detector {cfg.detector!r}")


def annotate(bgr: np.ndarray, det: Detections, cfg: Settings, text: str = "") -> np.ndarray:
    out = bgr.copy()
    h, w = out.shape[:2]
    for band, color in ((cfg.center_band, (90, 90, 90)), (cfg.center_band_near, (0, 200, 255))):
        dx = int(band * w / 2)
        cv2.line(out, (w // 2 - dx, 0), (w // 2 - dx, h), color, 1)
        cv2.line(out, (w // 2 + dx, 0), (w // 2 + dx, h), color, 1)
    if det.horizon is not None:
        y = int(det.horizon)
        cv2.line(out, (0, y), (w, y), (255, 0, 255), 1)  # where the floor ends
    if det.goal:
        g = det.goal
        cv2.rectangle(out, (int(g.x0), int(g.y0)), (int(g.x1), int(g.y1)), (255, 120, 0), 2)
        cv2.line(out, (int(g.cx), int(g.y0)), (int(g.cx), int(g.y1)), (255, 120, 0), 1)
    if det.ball:
        b = det.ball
        cv2.circle(out, (int(b.cx), int(b.cy)), max(2, int(b.r)), (0, 255, 0), 2)
        cv2.circle(out, (int(b.cx), int(b.cy)), 2, (0, 0, 255), -1)
    if text:
        cv2.putText(out, text, (4, h - 6), cv2.FONT_HERSHEY_SIMPLEX, 0.38, (0, 0, 0), 3, cv2.LINE_AA)
        cv2.putText(out, text, (4, h - 6), cv2.FONT_HERSHEY_SIMPLEX, 0.38, (255, 255, 255), 1, cv2.LINE_AA)
    return out
