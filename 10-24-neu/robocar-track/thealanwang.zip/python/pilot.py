"""Runs one button-started attempt: fresh frame -> detect -> decide -> pulse.

Any lost ball, stale video, sensor or detector failure ends the run; the
caller's robot.run_program() then stops the motors and waits for BOOT.
"""

from __future__ import annotations

import time
import traceback
from pathlib import Path

import cv2

from brain import Action, Brain
from camera import MjpegCamera, StaleVideo
from config import Settings
from observation import Observation
from runlog import RunLog
from tracker import BallTracker

MIN_PULSE_MS = 20
MAX_PULSE_MS = 1500
MAX_BAD_FRAMES = 3  # corrupt JPEGs in a row before the run is treated as failed


class RunAborted(Exception):
    pass


def ultrasonic(sensors: dict) -> int:
    """Distance in mm, or -1 when unknown. A failed read shows up as -1 or
    as 65535 (0xFFFF) depending on the sensor."""
    mm = int(sensors.get("ultrasonic_mm", -1))
    return mm if 0 <= mm <= 5000 else -1


class Pilot:
    def __init__(self, robot, camera: MjpegCamera, detector, cfg: Settings, data_dir: Path,
                 button_stop: type[Exception]) -> None:
        self.robot = robot
        self.camera = camera
        self.detector = detector
        self.cfg = cfg
        self.data_dir = data_dir
        self.button_stop = button_stop

    def play(self) -> None:
        self._guarded(self._play, "play")

    def observe(self) -> None:
        self._guarded(self._observe, "observe")

    def _guarded(self, routine, label: str) -> None:
        self.tracker = BallTracker(self.cfg)
        log = RunLog(self.cfg, self.data_dir, label)
        try:
            outcome = routine(log)
        except self.button_stop:
            log.finish("stopped by button")
            raise
        except RunAborted as exc:
            outcome = f"stopped: {exc}"
        except StaleVideo as exc:
            outcome = f"stopped: stale video, {exc}"
        except Exception as exc:
            traceback.print_exc()
            outcome = f"stopped: error {type(exc).__name__}: {exc}"
        log.finish(outcome)

    def _sensors(self) -> dict:
        sensors = self.robot.read_sensors()
        if not sensors.get("program_enabled"):
            raise self.button_stop()
        return sensors

    def _look(self, t0: float, newer_than: float, min_seq: int = 0):
        for attempt in range(MAX_BAD_FRAMES + 1):
            frame = self.camera.wait_frame(newer_than, self.cfg.stale_frame_s, min_seq)
            age = time.monotonic() - frame.t
            if age > self.cfg.stale_frame_s:
                raise StaleVideo(f"newest frame is {age:.2f}s old")
            try:
                image = frame.decode()
                break
            except ValueError as exc:
                if attempt == MAX_BAD_FRAMES:
                    raise
                print(f"[WARN] {exc}, using the next frame")
                newer_than, min_seq = frame.t, frame.seq + 1
        if self.cfg.camera_mirrored:
            image = cv2.flip(image, 1)
        started = time.monotonic()
        det = self.tracker.update(self.detector.detect(image))
        detect_ms = (time.monotonic() - started) * 1000
        sensors = self._sensors()
        h, w = image.shape[:2]
        obs = Observation(frame.t - t0, w, h, det.ball, det.goal, ultrasonic(sensors))
        return frame, image, det, obs, age * 1000, detect_ms

    def _play(self, log: RunLog) -> str:
        brain = Brain(self.cfg)
        t0 = time.monotonic()
        newer_than = t0
        min_seq = 0
        step = 0
        sensors = self._sensors()
        print(f"[INFO] play: camera {self.camera.fps():.1f} fps, detector {self.detector.name}, "
              f"battery {sensors.get('battery_mv', '?')} mV, ultrasonic {ultrasonic(sensors)} mm")
        while True:
            step += 1
            frame, image, det, obs, age_ms, detect_ms = self._look(t0, newer_than, min_seq)
            action = brain.decide(obs)
            log.step(step, obs, det, action, image, age_ms, detect_ms, frame.jpeg)

            if action.kind == "move":
                self._pulse(action)
                self.tracker.moved(((action.direction, action.speed, action.ms),) + action.then)
                newer_than = time.monotonic() + self.cfg.settle_s
                latest = self.camera.latest()
                min_seq = (latest.seq if latest else 0) + self.cfg.settle_frames + 1
            elif action.kind == "wait":
                newer_than = frame.t
                min_seq = 0
            elif action.kind == "done":
                if brain.final_push:
                    self.robot.buzz()
                return f"done: {action.reason} after {obs.t:.1f}s, {brain.pushes} pushes"
            else:
                raise RunAborted(action.reason)

    def _pulse(self, action: Action) -> None:
        for direction, speed, ms in ((action.direction, action.speed, action.ms),) + action.then:
            ms = max(MIN_PULSE_MS, min(MAX_PULSE_MS, int(ms)))
            command = self.cfg.direction_map.get(direction, direction)
            self.robot.drive(command, speed=int(speed), ms=ms)

    def _observe(self, log: RunLog) -> str:
        """Detections only, wheels never commanded. Ends when BOOT is pressed;
        a stalled stream is reported and waited out, since nothing moves."""
        t0 = time.monotonic()
        newer_than = t0
        step = 0
        brain = Brain(self.cfg)
        print("[INFO] observe: motors stay off; press BOOT again to end")
        while True:
            step += 1
            try:
                frame, image, det, obs, age_ms, detect_ms = self._look(t0, newer_than)
            except self.button_stop:
                return f"observe ended after {step - 1} frames"
            except StaleVideo as exc:
                print(f"[WARN] {exc}; still waiting for the camera")
                try:
                    self._sensors()
                except self.button_stop:
                    return f"observe ended after {step - 1} frames"
                continue
            would = brain.decide(obs) if obs.t < self.cfg.run_time_limit_s else None
            log.step(step, obs, det, would, image, age_ms, detect_ms, frame.jpeg)
            newer_than = frame.t
            brain.reset()
